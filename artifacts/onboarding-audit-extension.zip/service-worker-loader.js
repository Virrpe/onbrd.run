import './assets/service-worker-loader.js-D3QlgskP.js';
